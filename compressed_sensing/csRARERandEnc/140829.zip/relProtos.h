/****************************************************************
 *
 * $Source: /pv/CvsTree/pv/gen/src/prg/methods/RARE/relProtos.h,v $
 *
 * Copyright (c) 1999-2001
 * BRUKER MEDICAL GMBH
 * D-76275 Ettlingen, Germany
 *
 * All Rights Reserved
 *
 * $Id: relProtos.h,v 1.1 2001/09/27 14:51:18 fhen Exp $
 *
 ****************************************************************/

#ifndef METHRELS_H
#define METHRELS_H

#ifndef CPROTO
#include "relProtos_p.h"
#endif

#endif

/****************************************************************/
/*      E N D   O F   F I L E                                   */
/****************************************************************/

